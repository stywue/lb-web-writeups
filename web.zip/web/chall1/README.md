# Web Challenge 1: Chess - Writeup

**Author:** marlithor-cyber
**Challenge Name:** Chess
**Category:** Web
**Difficulty:** Easy-Medium

## Challenge Description

The challenge presented us with a simple premise: "Beat Stockfish. You have no time limit."

When I first connected to the challenge, I was greeted with a WebSocket-based chess server. The goal seemed straightforward but impossible - beat one of the strongest chess engines in the world. Obviously, there had to be a trick.

## Initial Reconnaissance

I started by examining the provided files:
- `play_challenge.py` - A normal client implementation
- `solve.py` - An alternative client with some interesting options

The first thing I did was run the normal client to understand how the game flow works:

```bash
python3 play_challenge.py
```

The client connects via WebSocket, waits for a `game_start` message, sends a move, then waits for `move_made` response before sending the next move. This is the standard turn-based flow you'd expect from any chess game.

## Finding the Vulnerability

While reading through `solve.py`, I noticed something interesting - there's a `--burst` mode that behaves very differently from the normal client:

```python
if burst:
    for item in moves:
        payload = {"type": "move", "move": item}
        await ws.send(json.dumps(payload))
```

This code sends multiple moves back-to-back without waiting for any server response! This immediately caught my attention.

### The "Aha!" Moment

I realized that if the server doesn't properly enforce turn order, I could potentially send multiple white moves in a row before Stockfish (playing as black) gets a chance to respond. This would be a classic race condition or turn desynchronization bug.

## Developing the Exploit

The strategy became clear:
1. Connect to the server
2. Send a complete mating sequence as white
3. All moves get queued and processed before black can respond
4. Checkmate Stockfish without giving it a turn!

For the mating sequence, I chose the classic Scholar's Mate - one of the fastest checkmates in chess:

1. e2-e4 (pawn to e4)
2. Qd1-h5 (queen to h5)
3. Bf1-c4 (bishop to c4)
4. Qh5xf7# (queen takes f7, checkmate)

This works because:
- It's only 4 moves
- It's a forced mate if black doesn't defend
- Since black never gets a turn between our moves, there's no defense

## Exploitation

Running the exploit was simple:

```bash
python3 solve.py --burst e2e4 d1h5 f1c4 h5f7
```

Each argument gets converted to a JSON message:
```json
{"type":"move","move":"e2e4"}
{"type":"move","move":"d1h5"}
{"type":"move","move":"f1c4"}
{"type":"move","move":"h5f7"}
```

The `solve.py` script transmits all four moves immediately without waiting for responses.

### What Happens on the Server

1. White sends move 1 (e2e4)
2. White sends move 2 (d1h5) - before black responds!
3. White sends move 3 (f1c4) - still no black response!
4. White sends move 4 (h5f7) - checkmate!

The server processes these moves sequentially but doesn't enforce that black must move between white's moves. By the time Stockfish tries to respond, the game is already over.

## Root Cause Analysis

The vulnerability exists because:

1. **No Turn Validation**: The WebSocket handler accepts moves without verifying whose turn it is
2. **Asynchronous Processing**: The server processes queued messages faster than the chess engine can respond
3. **Missing Rate Limiting**: No throttling prevents multiple moves from the same player in quick succession

## Lessons Learned

This challenge teaches several important security concepts:

- **Never trust the client**: Just because the official client plays fairly doesn't mean all clients will
- **Server-side validation is critical**: Turn order should be enforced on the server, not just the client
- **Race conditions in game logic**: Asynchronous systems need careful state management
- **WebSocket security**: Real-time protocols need the same security considerations as HTTP

## Mitigation

To fix this vulnerability, the server should:

1. Track whose turn it is in the game state
2. Reject any move that comes from the wrong player
3. Only process the next move after the current move is fully resolved
4. Implement rate limiting on move submissions

## Conclusion

What seemed like an impossible challenge (beating Stockfish) turned out to be a clever lesson in finding and exploiting race conditions. The key was recognizing that the challenge wasn't about chess skill at all - it was about understanding the protocol and finding the flaw in turn enforcement.

The `--burst` mode in the provided `solve.py` was essentially a hint pointing us toward the solution. Sometimes the best exploits are hiding in plain sight!
